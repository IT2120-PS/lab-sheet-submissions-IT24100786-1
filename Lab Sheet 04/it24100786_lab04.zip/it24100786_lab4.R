setwd("C:\\Users\\it24100786\\Desktop\\it24100786")
getwd()

#Q1
branch_data <- read.csv("Exercise.txt", header = TRUE,sep = ",")
attach(branch_data)

#Q2
str(branch_data)

#Q3
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", ylab="Sales", col="lightblue", border="darkblue")

#Q4

summary(branch_data$Advertising_X2)        
fivenum(branch_data$Advertising_X2)       
IQR(branch_data$Advertising_X2)  

#Q5
find_outliers <- function(v) {
  Q1 <- quantile(v, 0.25)
  Q3 <- quantile(v, 0.75)
  IQR <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR
  upper <- Q3 + 1.5 * IQR
  v[v < lower | v > upper]
}
find_outliers(branch_data$Years_X3)

